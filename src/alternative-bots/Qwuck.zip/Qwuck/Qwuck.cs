using System;
using System.Linq;
using System.Drawing;
using System.Collections.Generic;
using Robocode.TankRoyale.BotApi;
using Robocode.TankRoyale.BotApi.Events;

// ------------------------------------------------------------------
// Qwuck
// ------------------------------------------------------------------
// Targeting: Circular
// Movement:  
// ------------------------------------------------------------------
/*

*/
// ------------------------------------------------------------------
public class Qwuck : Bot
{
    static double WALL_MARGIN = 30;
    static double CORNER_MARGIN = 100;
    static double OSCILLATION_RADIUS = 60;
    static double MAX_SPEED = 8;
    static double GUN_FACTOR = 5;
    static bool navigating = false;
    static Dictionary<int, EnemyData> enemies = new Dictionary<int, EnemyData>();
    static Random random = new Random();
    static Point2D corner = new Point2D(0, 0);
    static bool oneVsOne = false;
    static int targetId = -1;
    static bool targetLocked = false;


    static void Main()
    {
        new Qwuck().Start();
    }

    Qwuck() : base(BotInfo.FromFile("Qwuck.json")) { }

    public override void Run()
    {
        Console.WriteLine("Hello! I'm Qwuck!");
        
        BodyColor = Color.FromArgb(0x00, 0x64, 0x64); // Dark cyan
        TurretColor = Color.Yellow;
        RadarColor = Color.FromArgb(0x00, 0xC8, 0x00);   // lime
        BulletColor = Color.FromArgb(0x00, 0x96, 0x32); // green
        ScanColor = Color.Red;

        AdjustGunForBodyTurn = true;
        AdjustRadarForGunTurn = true;
        AdjustRadarForBodyTurn = true;

        MaxSpeed = MAX_SPEED;

        for (int i = 0; i < 8; i++) {
            TurnRadarRight(45);
        }
        AdjustGunForBodyTurn = true;
        navigating = true;

        corner = SafestCorner();
    } 

    public override void OnTick(TickEvent e) {
        // Console.WriteLine(string.Format("Safest corner: {0:0.00} {1:0.00}", corner.x, corner.y));
        if (navigating) {
            MoveTo(corner.x, corner.y);
            if (DistanceTo(corner.x, corner.y) < OSCILLATION_RADIUS) {
                TargetSpeed = 0;
                // SetTurnLeft(90);
                navigating = false;
            }
        } else {
            Oscillate();
        }

        if (DistanceTo(corner.x, corner.y) > CORNER_MARGIN * 1.5) {
            navigating = true;
        }
    
        if (!SafestCorner().Equals(corner)) {
            navigating = true;
            corner = SafestCorner();
        }

        if (oneVsOne) {
            if (targetLocked) {
                targetLocked = false;
                TrackScanAt(enemies[targetId].LastX, enemies[targetId].LastY);
                ShootPredict(enemies[targetId].LastX, enemies[targetId].LastY, enemies[targetId].LastSpeed, enemies[targetId].LastDirection, CalcFirePower(enemies[targetId].LastX, enemies[targetId].LastY));
            } else {
                SetTurnRadarLeft(45);
            }
        } else {
            SetTurnRadarLeft(45);
            int selectId = SelectTargetEnemy();
            if (selectId != -1) {
                ShootPredict(enemies[selectId].LastX, enemies[selectId].LastY, enemies[selectId].LastSpeed, enemies[selectId].LastDirection, CalcFirePower(enemies[selectId].LastX, enemies[selectId].LastY));
            }
        }
    }

    public override void OnScannedBot(ScannedBotEvent e) {
        if (!enemies.ContainsKey(e.ScannedBotId))
        {
            enemies[e.ScannedBotId] = new EnemyData();
        }

        enemies[e.ScannedBotId].LastX = e.X;
        enemies[e.ScannedBotId].LastY = e.Y;
        enemies[e.ScannedBotId].LastEnergy = e.Energy;
        enemies[e.ScannedBotId].LastSpeed = e.Speed;
        enemies[e.ScannedBotId].LastDirection = e.Direction;

        // Console.WriteLine(string.Format("id: {0:0} x: {1:0.00} y: {2:0.00} energy: {3:0.00} speed: {4:0.00} dir: {5:0.00}", 
        //     e.ScannedBotId, 
        //     e.X,
        //     e.Y,
        //     e.Energy,
        //     e.Speed,
        //     e.Direction
        //     ));
        // Console.WriteLine(string.Format("count: {0:0.00}", enemies.Count));
        if (DistanceTo(e.X, e.Y) < 200) {
            targetId = e.ScannedBotId;
            oneVsOne = true;
        } else {
            oneVsOne = false;
        }
        if (e.ScannedBotId == targetId) {
            targetLocked = true;
        }
    }

    public override void OnBotDeath(BotDeathEvent e) {
        if (enemies.ContainsKey(e.VictimId))
        {
            enemies.Remove(e.VictimId);
            if (e.VictimId == targetId) {
                oneVsOne = false;
                targetId = -1;
            }
            if (enemies.Count == 1) {
                targetId = enemies.Keys.First();
                oneVsOne = true;
            }
        }
    }

// ========================== METHODS ===============================

    private void Oscillate()
    {
        // TargetSpeed = OSCILLATION_RADIUS * TurnRate * Math.PI / 180;
        // TurnRate = 7 +  5 * Math.Sin(DateTime.UtcNow.Millisecond);
        // double v = 3;
        double minSpeed = 2;
        double wallSmoothTurnIncr = 2;
        double wallSmoothSpeedIncr = 2;
        Point2D magicStick = CalcMagicStick();
        if (IsCloseToWall() && IsOutsideArena(magicStick.x, magicStick.y)) {
            // TurnRate += wallSmoothTurnIncr * (TurnRate > 0 ? 1 : -1);
            // TargetSpeed -= wallSmoothSpeedIncr * (TargetSpeed > 0 ? 1 : -1);
            TurnRate = 10;
            TargetSpeed = 2;
        }
        TargetSpeed += 2.5 * random.NextDouble() * (random.NextDouble() > 0.4 ? 1 : -1);
        if (Math.Abs(TargetSpeed) < minSpeed) TargetSpeed = minSpeed * (random.NextDouble() > 0.4 ? 1 : -1);
        TurnRate = TargetSpeed * 180 / Math.PI / (OSCILLATION_RADIUS - random.NextDouble() * (OSCILLATION_RADIUS-10));
    }
    private bool IsCloseToWall()
    {
        return X < WALL_MARGIN || X > ArenaWidth - WALL_MARGIN || Y < WALL_MARGIN || Y > ArenaHeight - WALL_MARGIN;
    }

    private bool IsOutsideArena(double x, double y) {
        return x < 0 || x > ArenaWidth || y < 0 || y > ArenaHeight;
    }

    private Point2D SafestCorner() {
        Point2D[] corners = new Point2D[] {
            new Point2D(CORNER_MARGIN, CORNER_MARGIN),
            new Point2D(CORNER_MARGIN, ArenaHeight - CORNER_MARGIN),
            new Point2D(ArenaWidth - CORNER_MARGIN, CORNER_MARGIN),
            new Point2D(ArenaWidth - CORNER_MARGIN, ArenaHeight - CORNER_MARGIN)
        };
        Point2D safest = corners[0];
        double maxDistance = 0;
        double sumDistance = 0;
        foreach (Point2D corner in corners) {
            foreach (EnemyData enemy in enemies.Values) {
                sumDistance += Math.Sqrt(Math.Pow(corner.x - enemy.LastX, 2) + Math.Pow(corner.y - enemy.LastY, 2));
            }
            if (sumDistance > maxDistance) {
                maxDistance = sumDistance;
                safest = corner;
            }
            sumDistance = 0;
        }

        return safest;
    }

    private void MoveTo(double x, double y) {
        double turn = BearingTo(x, y);
        SetTurnLeft(turn);
        SetForward(DistanceTo(x, y));
    }

    private void TrackScanAt(double x, double y) {
        var bearingFromRadar = NormalizeRelativeAngle(RadarBearingTo(x, y));
        SetTurnRadarLeft(bearingFromRadar + (bearingFromRadar > 0 ? 20 : -20));
    }

    private int SelectTargetEnemy() {
        double minFactor = double.PositiveInfinity;
        int closestId = -1;
        foreach (int id in enemies.Keys) {
            double distance = DistanceTo(enemies[id].LastX, enemies[id].LastY);
            double energy = enemies[id].LastEnergy;
            double factor = distance * energy;
            if (factor < minFactor) {
                minFactor = factor;
                closestId = id;
            }
        }
        return closestId;
    }

    private double CalcFirePower(double targetX, double targetY)
    {
        return Energy / DistanceTo(targetX, targetY) * GUN_FACTOR;
    }

    private void ShootPredict(double targetX, double targetY, double targetSpeed, double targetDirection, double firePower) {
        double bulletSpeed = CalcBulletSpeed(firePower);

        double enemyDir = targetDirection * Math.PI / 180.0;
        
        double time = DistanceTo(targetX, targetY) / bulletSpeed;
        
        double predictedX = targetX + targetSpeed * time * Math.Cos(enemyDir);
        double predictedY = targetY + targetSpeed * time * Math.Sin(enemyDir);
        
        double angleToPredicted = GunBearingTo(predictedX, predictedY);
        double angleToEnemy = GunBearingTo(targetX, targetY);
        double turn = angleToPredicted > angleToEnemy ? angleToPredicted - 2 : angleToPredicted + 2;
        // SetTurnGunLeft(GunBearingTo(targetX, targetY));
        // double turn = Math.Asin(targetSpeed / CalcBulletSpeed(firePower)) * 180 / Math.PI;
        
        SetFire(firePower);
        SetTurnGunLeft(turn);
    }

    private Point2D CalcMagicStick() {
        double x = X + 100 * Math.Cos(Direction);
        double y = Y + 100 * Math.Sin(Direction);
        return new Point2D(x, y);
    }

}

class EnemyData {
    public double LastDirection { get; set; }
    public double LastSpeed { get; set;}
    public double LastX { get; set; }
    public double LastY { get; set; }
    public double LastEnergy { get; set; }
}

class Point2D {
    public double x;
    public double y;

    public Point2D(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public bool Equals(Point2D other) {
        return this.x == other.x && this.y == other.y;
    }
}